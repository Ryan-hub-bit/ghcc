godablooms
==========

For the Go package you can install outside of `make` via:

    $ go get github.com/bitly/dablooms/godablooms

However, we recommend using [go-install-as](https://github.com/mreiferson/go-install-as):

    $ go tool install_as --import-as=bitly/dablooms

To run tests:

    $ go test

