#ifndef __GEGL_CL_H__
#define __GEGL_CL_H__

#include "gegl-cl-types.h"
#include "gegl-cl-init.h"
#include "gegl-cl-color.h"
#include "glib/gprintf.h"

#endif
