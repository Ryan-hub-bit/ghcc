
extern char load_message[];
int load_save_mega(struct select_file_t *selector, char *filename);
