char __cdecl
*realpath( const char *__restrict__ name, char *__restrict__ resolved );

