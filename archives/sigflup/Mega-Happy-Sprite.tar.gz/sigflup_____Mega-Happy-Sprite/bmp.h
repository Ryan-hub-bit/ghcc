int load_bmp(struct select_file_t *selector, char *filename);
